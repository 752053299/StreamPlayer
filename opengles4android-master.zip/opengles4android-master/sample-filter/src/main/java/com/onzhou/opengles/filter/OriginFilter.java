package com.onzhou.opengles.filter;

/**
 * @anchor: andy
 * @date: 2019-03-27
 * @description:
 */
public class OriginFilter extends BaseFilter {


}
