package com.onzhou.opengles.base;


import androidx.appcompat.app.AppCompatActivity;

/**
 * @anchor: andy
 * @date: 2018-11-02
 * @description:
 */
public abstract class AbsBaseActivity extends AppCompatActivity {
}
